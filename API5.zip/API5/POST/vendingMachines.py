from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from db import get_connection

post_vm_blueprint = Blueprint("post_vm", __name__)


@post_vm_blueprint.post("/api/v1/VendingMachines")
def add_vending_machine():
    conn = None
    cursor = None
    try:
        data = request.get_json()
        if data is None:
            return jsonify({"error": "Неверный формат JSON"}), 400

        conn = get_connection()
        cursor = conn.cursor()

        date_of_next_fixing = data.get('DateOfNextFixing', '')
        if date_of_next_fixing:
            try:
                fix_date = datetime.strptime(date_of_next_fixing, '%Y-%m-%d')
                if fix_date <= datetime.now():
                    return "Измените дату следующего ремонта/обслуживания"
            except:
                pass

        query = """INSERT INTO VendingMachines 
                   (Location, Model, PaymentTypeID, FullIncome, SerialNumber, 
                    InventoryNumber, Manufacturer, ManufactureDate, DateOfCommissioning, 
                    LastVerificationDate, VerificationInterval, ResourceHours, 
                    DateOfNextFixing, MaintenanceTimeHours, MachineStatusID, 
                    CountryID, InventoryDate, LastCheckedByUserID) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

        params = (
            str(data.get('Location', '')),
            str(data.get('Model', '')),
            int(data['PaymentTypeID']),
            float(data.get('FullIncome', 0.0)),
            str(data.get('SerialNumber', '')),
            str(data.get('InventoryNumber', '')),
            str(data.get('Manufacturer', '')),
            str(data.get('ManufactureDate', '')),
            str(data.get('DateOfCommissioning', '')),
            str(data.get('LastVerificationDate', '')),
            int(data.get('VerificationInterval', 0)),
            int(data.get('ResourceHours', 0)),
            date_of_next_fixing,
            int(data.get('MaintenanceTimeHours', 0)),
            int(data['MachineStatusID']),
            int(data['CountryID']),
            str(data.get('InventoryDate', '')),
            int(data['LastCheckedByUserID'])
        )

        cursor.execute(query, params)
        conn.commit()


        cursor.execute("SELECT SCOPE_IDENTITY()")
        return jsonify({
            "message": "Запись торгового автомата успешно создана"
        }), 201

    except ValueError as e:
        return jsonify({"error": f"Ошибка преобразования данных: {str(e)}"}), 400
    except Exception as e:
        print(f"Полная ошибка: {e}")
        if conn:
            conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()